from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from database.connection import get_db
from models.users import User
from auth.hash_password import hash_password, verify_password
from auth.jwt_handler import create_access_token, verify_access_token
from pydantic import BaseModel, EmailStr

router = APIRouter()

# 토큰 블랙리스트 (메모리 기반)
token_blacklist = set()

# 요청 모델 정의
class UserSignUp(BaseModel):
    email: EmailStr
    password: str
    username: str

class UserSignIn(BaseModel):
    email: EmailStr
    password: str

# 회원가입 엔드포인트
@router.post("/signup")
def signup(user: UserSignUp, db: Session = Depends(get_db)):
    try:
        existing_user = db.query(User).filter(User.email == user.email).first()
        if existing_user:
            raise HTTPException(status_code=400, detail="Email already registered")
        hashed_password = hash_password(user.password)
        new_user = User(email=user.email, password=hashed_password, username=user.username)
        db.add(new_user)
        db.commit()
        return {"message": "User successfully registered"}
    except Exception as e:
        print(f"Error: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")

# 로그인 엔드포인트
@router.post("/signin")
def signin(user: UserSignIn, db: Session = Depends(get_db)):
    # 사용자 조회
    db_user = db.query(User).filter(User.email == user.email).first()
    if not db_user or not verify_password(user.password, db_user.password):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    
    # JWT 토큰 생성
    token = create_access_token({"sub": db_user.email})
    return {"access_token": token, "token_type": "bearer"}

# 로그아웃 엔드포인트
@router.post("/signout")
def signout(token: str = Depends(verify_access_token)):
    """
    로그아웃: 사용 중인 JWT 토큰을 블랙리스트에 추가하여 무효화
    """
    token_blacklist.add(token)
    return {"message": "User successfully logged out"}

# 보호된 라우트 예시
@router.get("/protected-route")
def protected_route(token: str = Depends(verify_access_token)):
    """
    보호된 API 예제. 로그아웃된 토큰은 접근 불가
    """
    return {"message": "Access granted", "user": token}

