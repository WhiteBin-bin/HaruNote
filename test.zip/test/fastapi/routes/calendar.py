from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from database.connection import get_db
from models.calendar import Calendar
from pydantic import BaseModel
from typing import List
from datetime import datetime

router = APIRouter()

# 캘린더 이벤트 생성 요청 데이터 모델
class CalendarCreate(BaseModel):
    title: str
    description: str
    event_date: str  # ISO 형식의 문자열 날짜 (예: "2024-01-01T10:00:00")

# 캘린더 이벤트 응답 데이터 모델
class CalendarResponse(BaseModel):
    id: int
    title: str
    description: str
    event_date: datetime
    created_at: datetime
    is_public: bool

    class Config:
        orm_mode = True  # SQLAlchemy 모델을 JSON으로 변환

@router.get("/list", response_model=List[CalendarResponse])
def get_event_list(db: Session = Depends(get_db)):
    """
    캘린더 항목 목록 가져오기
    """
    events = db.query(Calendar).all()
    if not events:
        raise HTTPException(status_code=404, detail="No events found")
    return events

@router.get("/list/{note_id}", response_model=CalendarResponse)
def get_event_details(note_id: int, db: Session = Depends(get_db)):
    """
    특정 이벤트 세부 정보 가져오기
    """
    event = db.query(Calendar).filter(Calendar.id == note_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")
    return event

@router.get("/search", response_model=List[CalendarResponse])
def search_calendar(keyword: str, db: Session = Depends(get_db)):
    """
    제목을 기준으로 캘린더 이벤트 검색
    """
    events = db.query(Calendar).filter(Calendar.title.contains(keyword)).all()
    if not events:
        raise HTTPException(status_code=404, detail="No events found for the given keyword")
    return events

@router.post("/create", response_model=CalendarResponse)
def create_event(event: CalendarCreate, db: Session = Depends(get_db)):
    """
    새로운 캘린더 항목 생성
    """
    try:
        # 문자열 날짜를 datetime 객체로 변환
        event_date = datetime.fromisoformat(event.event_date)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid event_date format")

    new_event = Calendar(
        title=event.title,
        description=event.description,
        event_date=event_date
    )
    db.add(new_event)
    db.commit()
    db.refresh(new_event)  # 새로 생성된 데이터 반환
    return new_event
