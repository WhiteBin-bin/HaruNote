from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from routes.users import router as user_router
from routes.calendar import router as calendar_router
from database.connection import Base, engine, get_db
from sqlalchemy.orm import Session
from models.calendar import Calendar
from datetime import datetime
from sqlalchemy import or_

app = FastAPI()

# CORS 설정
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 모든 도메인 허용
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 라우터 포함
app.include_router(user_router, prefix="/api/user", tags=["Users"])
app.include_router(calendar_router, prefix="/api/calendar", tags=["Calendar"])

# 데이터베이스 초기화 함수
def initialize_database():
    """
    데이터베이스 테이블을 생성합니다.
    """
    print("Initializing database...")
    Base.metadata.create_all(bind=engine)
    print("Database initialized successfully.")

# 쿼리 함수들
def get_public_events(db: Session):
    """
    공개된 항목을 최신순으로 가져오기
    """
    return db.query(Calendar).filter(Calendar.is_public == True).order_by(Calendar.created_at.desc()).all()

def get_events_by_date_range(db: Session, start_date: datetime, end_date: datetime):
    """
    특정 날짜 범위로 필터링
    """
    return db.query(Calendar).filter(
        Calendar.event_date >= start_date,
        Calendar.event_date <= end_date
    ).all()

def search_events(db: Session, keyword: str):
    """
    제목과 설명에서 키워드 검색
    """
    return db.query(Calendar).filter(
        Calendar.is_public == True,
        or_(
            Calendar.title.ilike(f"%{keyword}%"),
            Calendar.description.ilike(f"%{keyword}%")
        )
    ).all()

def get_events_by_date(db: Session, target_date: datetime):
    """
    특정 날짜의 이벤트 검색
    """
    return db.query(Calendar).filter(
        Calendar.event_date == target_date
    ).all()

# API 루트 엔드포인트
@app.get("/")
async def root():
    return {"message": "API is running"}

# 스크립트 실행
if __name__ == "__main__":
    initialize_database()  # 데이터베이스 초기화

    db: Session = next(get_db())  # 데이터베이스 세션 생성

    # Test 쿼리 함수들
    print("\n--- Testing Queries ---")
    print("Public events:", get_public_events(db))
    print("Events by date range:", get_events_by_date_range(db, datetime(2024, 1, 1), datetime(2024, 12, 31)))
    print("Search events:", search_events(db, "여행"))
    print("Events by specific date:", get_events_by_date(db, datetime(2024, 4, 25)))



