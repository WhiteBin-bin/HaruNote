from sqlalchemy import Column, Integer, String, DateTime, Boolean
from database.connection import Base
from datetime import datetime

class Calendar(Base):
    __tablename__ = "calendar"  # 테이블 이름
    id = Column(Integer, primary_key=True, index=True)  # Primary Key
    title = Column(String(255), nullable=False)  # 제목 (VARCHAR 255, NOT NULL)
    description = Column(String(1000), nullable=True)  # 설명 (VARCHAR 1000, NULL 허용)
    event_date = Column(DateTime, nullable=False)  # 이벤트 날짜 (DATETIME, NOT NULL)
    created_at = Column(DateTime, default=datetime.utcnow)  # 생성 날짜 (DATETIME, 기본값: 현재 시간)
    is_public = Column(Boolean, default=True)  # 공개 여부 (BOOLEAN, 기본값: 공개)