from sqlalchemy import Column, Integer, String
from database.connection import Base

class User(Base):
    __tablename__ = "user"  # 테이블 이름이 "user"로 설정됨
    id = Column(Integer, primary_key=True, index=True)  # Primary Key
    email = Column(String(255), unique=True, nullable=False)  # VARCHAR(255), UNIQUE
    password = Column(String(255), nullable=False)  # VARCHAR(255), NOT NULL
    username = Column(String(255), nullable=False)  # VARCHAR(255), NOT NULL

