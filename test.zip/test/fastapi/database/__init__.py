from database.connection import engine, Base
from models.calendar import Event
from models.users import User

def init_db():
    """
    데이터베이스 초기화를 수행합니다.
    모든 모델(Base.metadata)을 이용해 테이블을 생성합니다.
    """
    # 데이터베이스 테이블 생성
    Base.metadata.create_all(bind=engine)